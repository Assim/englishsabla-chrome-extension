/*!
 * English Sabla Mozilla Firefox Extension
 * http://englishsabla.com/
 *
 * Copyright 2010, Assim Al-Marhuby
 * http://assim.me/
 */

pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_username", "");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_resize_post_images", "");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_forum_categories", "");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_signatures", "");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.customisation_activated", "no");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.content_script_version", "");
pref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.addon_version", "");