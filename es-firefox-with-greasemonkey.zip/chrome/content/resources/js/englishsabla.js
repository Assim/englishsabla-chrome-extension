/*!
 * English Sabla Mozilla Firefox Extension
 * http://englishsabla.com/
 *
 * Copyright 2010, Assim Al-Marhuby
 * http://assim.me/
 */

window.addEventListener("load", function() { englishsabla.init(); }, false);

var englishsabla = {

  init: function() {  
    // Init code here
  },

  show_popup: function() {
    // Open popup
    window.open("chrome://englishsabla/content/popup.xul", "", "chrome");
  },

  show_customise: function() {
    // Open popup
    window.open("chrome://englishsabla/content/customise.xul", "", "chrome");
  }

};