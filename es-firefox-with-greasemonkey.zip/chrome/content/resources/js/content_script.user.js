// ==UserScript==
// @name           English Sabla
// @namespace      http://www.englishsabla.com
// @include        http://englishsabla.com/*
// @include        http://www.englishsabla.com/*
// ==/UserScript==

// Set content version here
GM_setValue("content_script_version", "1.0");

var $;

// Script context (very important line to make this work)
// No need in Chrome extension
var doc = window.content.document;

// Add jQuery
(function(){
	if (typeof unsafeWindow.jQuery == 'undefined') {
		var GM_Head = document.getElementsByTagName('head')[0] || document.documentElement,
			GM_JQ = document.createElement('script');

		GM_JQ.src = 'http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js';
		GM_JQ.type = 'text/javascript';
		GM_JQ.async = true;

		GM_Head.insertBefore(GM_JQ, GM_Head.firstChild);
	}
	GM_wait();
})();

// Check if jQuery's loaded
function GM_wait() {
	if (typeof unsafeWindow.jQuery == 'undefined') {
		window.setTimeout(GM_wait, 100);
	} else {
		$ = unsafeWindow.jQuery.noConflict(true);
		letsJQuery();
	}
}

// All your GM code must be inside this function
function letsJQuery() {
	//alert($); // check if the dollar (jquery) function works
	//alert($().jquery); // check jQuery version

	// Import version settings
	var content_script_version = GM_getValue("content_script_version");
	var addon_version = GM_getValue("addon_version");

	// Import settings
	var esoption_username =                  GM_getValue("esoption_username");
	var esoption_thread_resize_post_images = GM_getValue("esoption_thread_resize_post_images");
	var esoption_forum_categories =          GM_getValue("esoption_forum_categories");
	var esoption_thread_signatures =         GM_getValue("esoption_thread_signatures");

	// Check if scripts needs updating, if yes, put a message on top to update
	//if(content_script_version != addon_version)
	//{
		$("body").prepend('<center><b><font color="red">Your customisation option is not up-to-date, please reactivate it by going to Customisation Options.</font></b></center>');
	//}

	// Add "Customise" link in navbar after 2nd link (1st index)
	$("td.vbmenu_control:eq(1)", doc).after('<td class="vbmenu_control"><a href="chrome://englishsabla/content/resources/html/customise.html" target="_blank">Customise</a></td>');

	// Insert username on login form
	// Check if the field is not empty
	if(esoption_username != "")
	{
		$("input#navbar_username", doc)
		.attr("value", esoption_username);
	}

	// Option: esoption_thread_resize_post_images
	if(esoption_thread_resize_post_images == "checked")
	{
		// Select all images in posts
		$("div[id^='post_message_']", doc)
		.find("img")

		// Loop through every image
		.each(function() {
			// Specify maximum image width
			var max_image_width = 468;

			// Selected image width and height
			var width = $(this, doc).width();
			var height = $(this, doc).height();
	
			// Check if image width bigger than max image width
			if ($(this, doc).width() > max_image_width)
			{
				// Calculate new image dimensions
				var ratio = max_image_width / $(this).width();
				width = max_image_width;
				height = $(this, doc).height() * ratio; 
            
				// Resize image
				$(this, doc).width(width).height(height);

				// Get image URL
				var img_url = $(this, doc).attr("src");

				// Show "Full link" under resized image
				var link = '<br /><font size="1"><img src="chrome://englishsabla/content/resources/images/icons/zoom.png"> <a href="' + img_url + '" target="_blank">Show full-sized image</a></font>';
				$(this, doc).after(link);
			}
		});
	}

	// Option: esoption_forum_categories
	if(esoption_forum_categories == "checked")
	{
		// Select the img with an id that starts with "collapseimg_forumbit_"
		$("img[id^='collapseimg_forumbit_']", doc)

		// Go to the 4th parent
		.parent()
		.parent()
		.parent()
		.parent()

		// Then hide it
		.hide();
	}

	// Option: esoption_thread_signatures
	if(esoption_thread_signatures == "checked")
	{
		// Select the div after the div that has an ID that starts with "post_message_"
		$("div[id^='post_message_'] + div", doc)

		// Then hide it
		.hide();
	}
}