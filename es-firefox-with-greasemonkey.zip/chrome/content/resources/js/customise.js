/*!
 * English Sabla Mozilla Firefox Extension
 * http://englishsabla.com/
 *
 * Copyright 2010, Assim Al-Marhuby
 * http://assim.me/
 */

$(document).ready(function() {

  // Reference the preferences system of Mozilla
  var prefManager = Components.classes["@mozilla.org/preferences-service;1"]
  .getService(Components.interfaces.nsIPrefBranch);

  // Import settings
  var esoption_username =                  prefManager.getCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_username");
  var esoption_thread_resize_post_images = prefManager.getCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_resize_post_images");
  var esoption_forum_categories =          prefManager.getCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_forum_categories");
  var esoption_thread_signatures =         prefManager.getCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_signatures");
  var customisation_activated =            prefManager.getCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.customisation_activated");

  // If customisation activated, hide activation, else, hide options.
  if(customisation_activated == "yes")
  {
    $("div#activation").hide();
  }
  else
  {
    $("div#options").hide();
  }

  // If customisation activated clicked, show options div and hide activation div
  $("button#customisation_activated").click(function() {
    $("div#options").show();
    $("div#activation").hide();

    // Save this in preferences so the options is shown and activation is hidden
    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.customisation_activated", "yes");
  });

  // If customisation deactivated clicked, show activation div and hide options div
  $("#customisation_deactivated").click(function() {
    $("div#activation").show();
    $("div#options").hide();

    // Save this in preferences so the options is shown and activation is hidden
    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.customisation_activated", "no");
  });

  // Fill in form
  $("input#esoption_username").attr("value", esoption_username);
  if(esoption_thread_resize_post_images == "checked")
  {
    $("input#esoption_thread_resize_post_images").attr("checked", "checked").attr("value", "checked");
  }
  if(esoption_forum_categories == "checked")
  {
    $("input#esoption_forum_categories").attr("checked", "checked").attr("value", "checked");
  }
  if(esoption_thread_signatures == "checked")
  {
    $("input#esoption_thread_signatures").attr("checked", "checked").attr("value", "checked");
  }

  // Add checked in "value" attribute if checked, or remove the attribute if not checked for checkbox inputs
  $("input[type='checkbox']").change(function() {
    if($(this).attr("value") == "checked")
    {
      $(this).removeAttr("value");
    }
    else
    {
      $(this).attr("value", "checked");
    }
  });

  // When the save button is clicked
  $("button#save").click(function() {
    // Save data in localStorage
    var save_esoption_username =                  $("input#esoption_username").val();
    var save_esoption_thread_resize_post_images = $("input#esoption_thread_resize_post_images").val();
    var save_esoption_forum_categories =          $("input#esoption_forum_categories").val();
    var save_esoption_thread_signatures =         $("input#esoption_thread_signatures").val();

    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_username", save_esoption_username);
    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_resize_post_images", save_esoption_thread_resize_post_images);
    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_forum_categories", save_esoption_forum_categories);
    prefManager.setCharPref("greasemonkey.scriptvals.http://www.englishsabla.com/English Sabla.esoption_thread_signatures", save_esoption_thread_signatures);

    // Disable save button
    $("button#save").attr("disabled", "disabled").html("Customisations Saved");
  });

  // Enable "Save" button if inputs have been changed
  $(":input").change(function() {
    $("button#save:disabled").removeAttr("disabled").html("Save Customisations");
  });

});